<?php
	defined('_JEXEC') or die();

	class ProductFilterController extends JControllerLegacy{
		protected $default_view = 'productfilter_list';
	}
?>