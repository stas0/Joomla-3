<?php
header("Content-type: text/css; charset: UTF-8");

$id = $_GET["id"];
?>