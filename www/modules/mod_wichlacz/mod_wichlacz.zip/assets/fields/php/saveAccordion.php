<?php
file_put_contents(dirname(__FILE__) . '/../data/data.txt', $_POST["accordion"]);

echo 'good';
?>